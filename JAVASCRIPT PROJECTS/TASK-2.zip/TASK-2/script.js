
function myfunction() {
	document.getElementById("changed").style.cssText = "display:block"
}
function myfunction2() {
	document.getElementById("changed").style.cssText = "display:none"
}

